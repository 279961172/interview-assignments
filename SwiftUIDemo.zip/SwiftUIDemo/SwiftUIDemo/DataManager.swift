//
//  DataManager.swift
//  SwiftUIDemo
//
//  Created by nick on 2022/3/23.
//

import Foundation

class DataManager: ObservableObject {
    @Published var items: [SoftwareItemModel] = []
    
    func fetchItemList(index: Int) {
        guard index >= self.items.count - 1 else {
            return
        }
        let url = URL(string: "https://itunes.apple.com/search?entity=software&limit=50&term=chat&offset=\(self.items.count)")!
        URLSession.shared.dataTask(with: url) { (data, _, error) in
            guard let data = data else {
                print(error?.localizedDescription)
                return
            }
            
            DispatchQueue.main.async {
                do {
                    let items = try JSONDecoder().decode(NetworkResponse<[SoftwareItemModel]>.self, from: data).results
                    if index == 0 {
                        self.items = items
                    } else {
                        self.items.append(contentsOf: items)
                    }
                } catch let err {
                    print(err.localizedDescription)
                }
            }
        }.resume()
    }
}
