//
//  SoftwareListCell.swift
//  SwiftUIDemo
//
//  Created by nick on 2022/3/22.
//

import SwiftUI

struct SoftwareListCell: View {
    @Binding var model: SoftwareItemModel
    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            WebImageView(iconImageUrl: model.iconUrl)
            
            VStack(alignment: .leading) {
                Text(model.title)
                    .lineLimit(1)
                Text(model.description)
                    .lineLimit(2)
            }
            
            Spacer()
            
            Button {
                model.isFavorite.toggle()
            } label: {
                Image(systemName: model.isFavorite ? "heart.fill" : "heart")
                    .resizable()
                    .frame(width: 30, height: 30)
                    .aspectRatio(contentMode: .fit)
                    .foregroundColor(model.isFavorite ? Color.red : Color.gray)
            }
        }.padding()
    }
}

struct SoftwareListCell_Previews: PreviewProvider {
    static let title = "Viber Messenger: Chats & Calls"
    static let url = "https://is2-ssl.mzstatic.com/image/thumb/Purple126/v4/22/c6/a6/22c6a63d-427b-5a19-6ed0-1eeb1c316aa5/source/60x60bb.jpg"
    static let description = "Google Chat is an intelligent and secure communication and collaboration tool, built for teams. From ad-hoc messaging to topic-based workstream collaboration, Chat makes it easy to get work done where the conversation is happening.\n\n• Group collaboration that allows Google Workspace content creation and sharing (Docs, Sheets, Slides), without having to worry about granting"
    @State static var model = SoftwareItemModel(title: title,
                                         iconUrl: url,
                                         description: description)
    @State static var model2 = SoftwareItemModel(title: title,
                                         iconUrl: url,
                                         description: description,
                                          isFavorite: true)
    static var previews: some View {
        Group {
            SoftwareListCell(model: $model)
            SoftwareListCell(model: $model2)
        }.previewLayout(.fixed(width: 300, height: 80))
    }
}
