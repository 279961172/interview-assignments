//
//  SoftwareItemModel.swift
//  SwiftUIDemo
//
//  Created by nick on 2022/3/22.
//

import Foundation

struct NetworkResponse<T: Codable> : Codable {
    let resultCount: Int
    let results: T
}

struct SoftwareItemModel: Codable {
    var title: String
    var iconUrl: String
    var description: String
    
    var isFavorite = false
    
}

extension SoftwareItemModel {
    enum CodingKeys: String, CodingKey {
        case title = "trackCensoredName"
        case iconUrl = "artworkUrl60"
        case description
    }
}
