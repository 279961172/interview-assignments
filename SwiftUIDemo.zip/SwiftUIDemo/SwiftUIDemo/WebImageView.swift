//
//  WebImageView.swift
//  SwiftUIDemo
//
//  Created by nick on 2022/3/23.
//

import SwiftUI
import Kingfisher

struct WebImageView: View {
    var iconImageUrl: String
    var body: some View {
        KFImage(URL(string: iconImageUrl))
         .resizable()
         .frame(width: 60, height: 60)
         .aspectRatio(contentMode: .fit)
         .shadow(radius: 4)
         .cornerRadius(5)
         .overlay(RoundedRectangle(cornerRadius: 5)
                    .stroke(Color(white: 0.9), style: StrokeStyle(lineWidth: 1)))
    }
}

struct WebImageView_Previews: PreviewProvider {
    static var previews: some View {
        WebImageView(iconImageUrl: "https://is2-ssl.mzstatic.com/image/thumb/Purple126/v4/22/c6/a6/22c6a63d-427b-5a19-6ed0-1eeb1c316aa5/source/60x60bb.jpg")
    }
}

