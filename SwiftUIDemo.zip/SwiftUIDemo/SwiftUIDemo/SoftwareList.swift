//
//  SoftwareList.swift
//  SwiftUIDemo
//
//  Created by nick on 2022/3/22.
//

import SwiftUI

struct SoftwareList: View {
    @EnvironmentObject var dataManager: DataManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                LazyVStack(alignment: .leading) {
                    ForEach (0 ..< dataManager.items.count, id: \.self) { index in
                        SoftwareListCell(model: $dataManager.items[index])
                            .background(Color.white)
                            .cornerRadius(10)
                            .fixedSize(horizontal: false, vertical: false)
                            .onAppear {
                                dataManager.fetchItemList(index: index)
                            }
                    }
                }
            }.padding(10)
            .onAppear {
                dataManager.fetchItemList(index: 0)
            }
            .background(Color(Color.RGBColorSpace.sRGB, red: 230/255.0, green: 230/255.0, blue: 230/255.0, opacity: 1))
            .navigationBarTitle("App")
        }
    }
}

struct SoftwareList_Previews: PreviewProvider {
    static var previews: some View {
        SoftwareList()
    }
}
