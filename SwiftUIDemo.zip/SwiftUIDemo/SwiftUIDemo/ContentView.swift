//
//  ContentView.swift
//  SwiftUIDemo
//
//  Created by nick on 2022/3/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        SoftwareList().environmentObject(DataManager())
            .background(Color(Color.RGBColorSpace.sRGB, red: 230/255.0, green: 230/255.0, blue: 230/255.0, opacity: 1))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
