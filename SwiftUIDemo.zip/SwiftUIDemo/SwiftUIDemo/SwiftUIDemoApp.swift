//
//  SwiftUIDemoApp.swift
//  SwiftUIDemo
//
//  Created by nick on 2022/3/22.
//

import SwiftUI

@main
struct SwiftUIDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
